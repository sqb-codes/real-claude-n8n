# Verdant Heights — Approved Project Information

**Version 2026-09 · Approved by Marketing and Compliance on 2026-09-30 · Owner: Marketing**

> **FICTIONAL TRAINING MATERIAL.** Meridian Estates Pvt Ltd, Verdant Heights, the registration
> number and every figure below are invented for a training exercise. Nothing here describes a real
> project. This file is the *only* permitted source of project facts for Builds 1, 2, 10 and Demo 22.

---

## BROCHURE

### Page 1 — The project

Verdant Heights is a residential development by Meridian Estates Pvt Ltd at Whitefield, Bengaluru.
Four towers (A, B, C and D), thirty floors each, 480 homes in total, set on 4.2 acres.

RERA Registration No.: **PRM/KA/RERA/1251/446/PR/251103/009988**
Details available on the official State RERA Authority website.

### Page 3 — Configurations

| Configuration | Saleable area | Carpet area | Homes | Units per floor |
|---|---|---|---|---|
| 2 BHK | 1,180 sq ft | 762 sq ft | 240 | 2 (unit 01, 02) |
| 3 BHK | 1,620 sq ft | 1,042 sq ft | 240 | 2 (unit 03, 04) |

Every home has two covered car parks for 3 BHK and one for 2 BHK. Unit 04 on each floor is
park facing.

### Page 4 — Possession

Possession for Towers A, B, C and D is **published as Mar-2027**, subject to the terms of the
agreement for sale, including the grace period stated in it.

### Page 6 — Amenities (as sanctioned)

- Clubhouse, **12,000 sq ft**
- Swimming pool at **podium level**
- Two landscaped parks
- EV-ready parking provision
- Gymnasium, indoor games room, multipurpose hall
- Children's play area
- 24×7 security with CCTV at entry and exit
- Rainwater harvesting and sewage treatment plant

*Amenities listed above are part of the sanctioned plan. Nothing else may be advertised as an
amenity of this project.*

### Page 8 — Location

Whitefield, Bengaluru. Nearest metro station is **3.2 km** from the project entrance. The brochure
states distances only; it does not state travel times.

### Page 11 — Legal and disclosures

Promoter: Meridian Estates Pvt Ltd. All images in marketing material are artistic impressions.
All specifications are subject to the agreement for sale. Statutory charges, taxes and other
charges are quoted separately in the cost sheet.

---

## FREQUENTLY ASKED QUESTIONS

**Q1. Where is the project located?**
Whitefield, Bengaluru. The site office is at the Tower A sales lounge.

**Q2. How many homes are there and in how many towers?**
480 homes across four towers of thirty floors each.

**Q3. What configurations are available?**
2 BHK of 1,180 sq ft saleable (762 sq ft carpet) and 3 BHK of 1,620 sq ft saleable
(1,042 sq ft carpet).

**Q4. When is possession?**
Published possession for Towers A–D is Mar-2027, subject to the agreement for sale.

**Q5. Is the project RERA registered?**
Yes. Registration No. PRM/KA/RERA/1251/446/PR/251103/009988. Project details are available on the
official State RERA Authority website.

**Q6. What approvals are in place?**
Plan sanction and fire NOC are on file. The occupancy certificate has not yet been obtained, as
the project is under construction.

**Q7. Can I visit the site, and how?**
Site visits are available Monday to Sunday, 10:00 to 18:00, with a slot booked in advance. Please
carry a photo ID. A sales executive will meet you at the Tower A sales lounge.

**Q8. What is included in the price?**
The quoted price is the unit consideration. Floor rise and preferential location charges, where
applicable, are shown as separate lines. Club membership, the infrastructure and maintenance
deposit, applicable taxes, stamp duty and registration charges are quoted separately in the cost
sheet.

**Q9. What is the published price range?**
2 BHK: Rs 1.05–1.18 Cr. 3 BHK: Rs 1.42–1.68 Cr. Ranges depend on floor and facing. Other charges
are quoted separately. Prices are as of the current price list and are subject to revision.

**Q10. Is home loan assistance available?**
The sales team can share the list of lenders who have approved the project. Loan sanction and terms
are between the buyer and the lender.

**Q11. What are the maintenance charges?**
Maintenance charges are stated in the agreement for sale and the allotment letter. The brochure
does not publish a rate.

**Q12. Can I change the layout of my home?**
Internal changes are subject to structural feasibility, approval and the terms of the agreement.
Please raise the request with the CRM team in writing.

---

## WHAT THIS FILE DOES NOT CONTAIN

Any assistant grounded in this file must answer **NOT STATED IN APPROVED MATERIAL** for all of the
following, because they are deliberately absent:

- Any discount, concession or negotiated price
- Any possession date more specific than the published month
- Any rental, resale or appreciation assurance
- Clubhouse readiness dates
- Travel times to any landmark
- Occupancy certificate status beyond "not yet obtained"
- Maintenance charge rates
- Any amenity not listed on page 6
