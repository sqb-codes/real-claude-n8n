# RERA — Plain-Language Excerpt for Training

> **THIS IS A PARAPHRASE, NOT THE LAW.**
> The passages below are plain-language restatements written for a classroom exercise (Build 1,
> RERA Clause Explainer). They are **not** the statutory text, they are incomplete, and they ignore
> state-specific rules, amendments and procedure. Never quote them externally, never file them, and
> never rely on them. The authoritative sources are the Real Estate (Regulation and Development)
> Act, 2016 as published, the rules of the applicable State RERA Authority, and your legal team.
>
> Clause labels such as `[S.13(1)]` indicate which provision the paraphrase is *about*, so that the
> verification step in the exercise has something to look up.

---

### [S.3] Registration of a project

A promoter shall not advertise, market, book, sell or offer for sale any plot, apartment or
building in a real estate project without first registering the project with the Authority, subject
to the exemptions set out in the Act.

### [S.4] Application for registration

An application for registration is made to the Authority with the particulars the Act requires,
which include details of the promoter, the project, the sanctioned plan, the proposed completion
schedule, and a declaration regarding the deposit of a prescribed share of amounts realised from
allottees in a separate account to be used for construction and land cost.

### [S.11(1)] Information to be made available

The promoter shall make available on the Authority's web page for the project the details the Act
requires, including sanctioned plans, approvals, the status of the project and the particulars
prescribed by the Authority.

### [S.11(3)] Information at the time of booking

At the time of booking and issue of the allotment letter, the promoter shall make available to the
allottee the sanctioned plans and layout plans along with specifications, approved by the competent
authority, and such other information as is prescribed.

### [S.12] Obligation regarding veracity of advertisement

Where a person makes an advance or a deposit on the basis of information contained in an
advertisement or prospectus, and sustains a loss or damage by reason of any incorrect, false
statement included in it, the person is entitled to compensation as provided in the Act; and a
person who wishes to withdraw on that account is entitled to be returned the amount invested as
provided in the Act.

### [S.13(1)] Limit on advance payment before agreement

A promoter shall not accept a sum exceeding ten per cent of the cost of the apartment, plot or
building as an advance payment or an application fee without first entering into a written
agreement for sale with the allottee and registering that agreement.

### [S.14] Adherence to sanctioned plans and project specifications

The proposed project shall be developed in accordance with the sanctioned plans, layout plans and
specifications as approved by the competent authorities, and alterations are subject to the
consents and conditions the Act specifies.

### [S.18] Return of amount and compensation

If the promoter fails to complete or is unable to give possession of an apartment, plot or building
in accordance with the terms of the agreement for sale, or as the case may be duly completed by the
date specified in it, the promoter is liable, on demand by the allottee who wishes to withdraw, to
return the amount received with interest and compensation as provided in the Act; and where the
allottee does not intend to withdraw, the promoter shall pay interest for every month of delay as
provided in the Act.

### [S.19] Rights and duties of allottees

The allottee is entitled to the information relating to sanctioned plans, layout plans and the
stage-wise time schedule of completion as provided in the Act, and is responsible for making the
payments in the manner and within the time specified in the agreement for sale, together with the
proportionate share of registration charges, municipal taxes and other outgoings as applicable.

---

## QUESTIONS THIS EXCERPT CAN ANSWER

Use these in the exercise; the assistant should answer with a clause reference and a FULLY
SUPPORTED confidence.

1. A buyer wants to pay 25% as booking amount before the agreement is signed. Is there a limit?
2. Can we advertise the project before registration?
3. What must be shown to the buyer at the time of booking?
4. Where must project information be published?
5. What is the position if the promoter cannot hand over possession as agreed?
6. What is the buyer's obligation on payments?

## QUESTIONS THIS EXCERPT CANNOT ANSWER

The only correct response is **NOT IN SUPPLIED EXCERPT**. Use these to test the refusal.

7. What is the penalty amount for a late quarterly update?
8. By which date must the Q3 FY27 update be filed in our state?
9. How many days do we have to respond to a complaint before the Authority?
10. What is the prescribed share of allottee money to be kept in the separate account?
11. Is our project compliant?
12. What is the interest rate payable for a delay in our state?
