# Agreement for Sale — Extract (Fictional)

> **FICTIONAL TRAINING DOCUMENT.** Simplified extract written for Demo 3 (Sale Agreement
> Summarizer), slide 17's reasoning exercise and Demo 8 (Payment Milestone Reminder). It is not a
> real agreement, it is not a template to use, and it is deliberately incomplete — two fields are
> missing so that the exercise can surface them.

---

**AGREEMENT FOR SALE**

Dated **12-Aug-2026**, at Bengaluru.

**BETWEEN** Meridian Estates Pvt Ltd, a company incorporated under the Companies Act, 2013, having
its registered office at Whitefield, Bengaluru (hereinafter the **"Promoter"**)

**AND** Ms Ananya Rao, residing at Bengaluru (hereinafter the **"Allottee"**)

Buyer reference: BR-2291

---

### Clause 2 — The Apartment

**2.1** The Promoter agrees to sell and the Allottee agrees to purchase Unit No. **VH-B-1204**,
on the **12th floor** of **Tower B**, in the project **Verdant Heights**, being a **3 BHK**
apartment of **1,620 sq ft** saleable area (**1,042 sq ft** carpet area), together with
**2 (two)** covered car parking spaces.

**2.2** The apartment is park facing.

### Clause 3 — Consideration

**3.1** The total consideration for the apartment is **Rs 1,51,63,200 (Rupees One Crore Fifty One
Lakh Sixty Three Thousand Two Hundred only)**, exclusive of taxes, statutory charges and other
charges, which are payable additionally as set out in the cost sheet annexed.

**3.2** The consideration comprises the base price, floor rise charges and preferential location
charges as set out in Annexure A (cost sheet).

### Clause 4 — Payment

**4.1** The Allottee shall pay the consideration in the manner set out in **Schedule II**.

**4.2** Payments under Schedule II are **construction linked**; an instalment becomes payable upon
the certification of the corresponding construction milestone by the Promoter's site engineer, and
upon the Promoter raising a demand in writing.

**4.3** Percentages in Schedule II apply to the consideration stated in Clause 3.1 and do not
include taxes, statutory charges or other charges.

### Clause 6 — Possession

**6.1** The Promoter shall hand over possession of the apartment on or before **31-Mar-2027**,
subject to Clause 6.4.

**6.4** A grace period of **six months** shall apply in the event of force majeure.

**6.5** For the purposes of Clause 6.4, force majeure includes any order of a statutory authority,
non-availability of materials, or labour unrest.

### Clause 9 — Interest and defaults

**9.3** On any instalment remaining unpaid beyond the due date stated in the demand, the Allottee
shall pay interest at **12% per annum** on the outstanding amount for the period of delay.

### Clause 12 — Notices

**12.1** Notices shall be in writing and delivered to the addresses stated above or to such other
address as a party notifies in writing.

---

### SCHEDULE II — PAYMENT PLAN (CONSTRUCTION LINKED)

| # | Milestone | % of consideration | Amount (Rs) |
|---|---|---|---|
| 1 | On booking | 10 | 15,16,320 |
| 2 | On agreement | 20 | 30,32,640 |
| 3 | On completion of foundation | 15 | 22,74,480 |
| 4 | On completion of 5th floor slab | 15 | 22,74,480 |
| 5 | On completion of 10th floor slab | 15 | 22,74,480 |
| 6 | On completion of brickwork | 10 | 15,16,320 |
| 7 | On completion of flooring | 10 | 15,16,320 |
| 8 | On possession | 5 | 7,58,160 |
| | **Total** | **100** | **1,51,63,200** |

---

### ANNEXURE A — COST SHEET (EXTRACT)

| Line | Basis | Amount (Rs) |
|---|---|---|
| Base price | 1,620 sq ft × Rs 8,900 | 1,44,18,000 |
| Floor rise | (12 − 5) floors × Rs 30 × 1,620 sq ft | 3,40,200 |
| Preferential location charge | Rs 250 × 1,620 sq ft | 4,05,000 |
| **Unit consideration** | | **1,51,63,200** |
| Club membership | fixed | 2,50,000 |
| Infrastructure and maintenance deposit | fixed | 1,80,000 |
| Taxes and statutory charges | as applicable, quoted separately | see cost sheet |

---

## DELIBERATE GAPS — for the extraction exercise

These are absent from the extract and the correct extracted value is **NOT FOUND**:

- Any remedy or interest payable by the **Promoter** for a delay in possession (note the asymmetry
  with Clause 9.3, which binds the Allottee only)
- **Maintenance** terms, charges or the period of the Promoter's maintenance obligation
- Clause 5, 7, 8, 10 and 11 (not reproduced in this extract)
- Dispute resolution and governing law
- The list of annexures other than Annexure A
