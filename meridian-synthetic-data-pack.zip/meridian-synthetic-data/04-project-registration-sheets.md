# Project Registration Sheets (Fictional)

> **FICTIONAL TRAINING DATA.** Registration numbers are invented in a realistic format. These
> sheets are the *approved source of project facts* against which generated marketing copy is
> checked in Demo 22 (Marketing Claim Verifier), and the reference data for Demo 11 (RERA
> Compliance Dashboard).

---

## 1. VERDANT HEIGHTS

| Field | Value |
|---|---|
| Promoter | Meridian Estates Pvt Ltd |
| Project | Verdant Heights, Phase 1 |
| Registration no. | PRM/KA/RERA/1251/446/PR/251103/009988 |
| Registration valid till | 31-Dec-2027 |
| Location | Whitefield, Bengaluru |
| Land area | 4.2 acres |
| Towers / floors | 4 towers (A–D), 30 floors each |
| **Total units** | **480** |
| Configurations | 2 BHK 1,180 sq ft saleable / 762 sq ft carpet; 3 BHK 1,620 sq ft saleable / 1,042 sq ft carpet |
| **Clubhouse** | **12,000 sq ft** |
| **Swimming pool** | **Yes — podium level** |
| Parks | 2 landscaped parks |
| Parking | EV-ready provision; 2 bays for 3 BHK, 1 for 2 BHK |
| **Published possession** | **Mar-2027** |
| Approvals on file | Plan sanction (PS/2214/2024); Fire NOC (2024, valid till 30-Nov-2026) |
| **Occupancy certificate** | **Not yet obtained** |
| Water and sewerage approval | Not uploaded (see compliance register) |
| **Rental or return assurance** | **None. No assured-return scheme exists for this project.** |
| **Nearest metro station** | **3.2 km** |
| Nearest school / hospital | 1.8 km / 2.4 km |
| Quarterly update status | Due 15-Oct-2026, not uploaded |

## 2. LAKEVIEW RESIDENCES

| Field | Value |
|---|---|
| Promoter | Meridian Estates Pvt Ltd |
| Project | Lakeview Residences |
| Registration no. | PRM/KA/RERA/1251/447/PR/260215/010442 |
| Registration valid till | 30-Jun-2029 |
| Location | Sarjapur Road, Bengaluru |
| Total units | 240 |
| Configurations | 3 BHK 1,780 sq ft; 4 BHK 2,340 sq ft |
| Stage | New launch |
| Clubhouse | 9,500 sq ft (under construction) |
| Swimming pool | Yes — ground level |
| Published possession | Dec-2028 |
| Approvals on file | Plan sanction; Fire NOC |
| Occupancy certificate | Not applicable at this stage |
| Rental or return assurance | None |
| Nearest metro station | 7.6 km |
| Quarterly update status | Uploaded 09-Oct-2026 |
| Open data gap | Project photographs — obligation has no due date entered |

## 3. ORION BUSINESS PARK

| Field | Value |
|---|---|
| Promoter | Meridian Estates Pvt Ltd |
| Project | Orion Business Park |
| Registration no. | PRM/KA/RERA/1251/312/PR/240710/006118 |
| Registration valid till | 31-Mar-2028 |
| Location | Outer Ring Road, Bengaluru |
| Asset type | Commercial office |
| Leasable area | 820,000 sq ft across 3 towers |
| Typical floor plate | 22,000 sq ft |
| Stage | Phase 1 complete; Phase 2 under construction |
| Occupancy certificate | Phase 1 OC on file, dated 22-Aug-2026 |
| Car park ratio | 1 bay per 1,000 sq ft leased |
| Published handover (Phase 2) | Sep-2027 |
| Rental or return assurance | None |
| Quarterly update status | Draft only — at risk |
| Open data gap | Environmental consent to operate — applicability to be confirmed |

---

## HOW THE VERIFIER USES THESE SHEETS

For each factual claim in a draft, the verifier returns one of:

- **SUPPORTED** — the sheet states it, quote the field
- **UNSUPPORTED** — the sheet states something different, or is silent; give the sheet's value
- **SUBJECTIVE** — not a factual claim (brand tone); allowed, marketing's decision
- **ESCALATE** — the claim is of a kind that needs legal clearance regardless of the sheet
  (assured returns, guaranteed rentals, buy-back, approvals described as complete)
