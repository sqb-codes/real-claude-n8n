# Clause Comparison Pair (Fictional)

> **FICTIONAL TRAINING DOCUMENT** for Demo 16 (Legal Clause Comparison). Simplified wording written
> for a classroom exercise. Not a template, not model wording, and not a view on what any clause
> means or whether it is enforceable.

Two versions of the same clause set. Version A is the developer's template; Version B came back
from a buyer's counsel. There are **four** differences. One of them is an omission.

---

## VERSION A — Meridian Estates template, Clause 6 (possession)

**6.1** The Promoter **shall hand over** possession of the apartment on or before 31-Mar-2027.

**6.2** Possession shall be handed over after receipt of the occupancy certificate and on payment
by the Allottee of all amounts due under this agreement.

**6.3** The Promoter shall give the Allottee not less than thirty days' written notice of the date
on which possession is to be taken.

**6.4** A grace period of **six months** shall apply in the event of force majeure.

**6.5** For the purposes of Clause 6.4, force majeure includes **any order of a statutory
authority, non-availability of materials, or labour unrest**.

**6.6** If the Allottee fails to take possession within sixty days of the notice under Clause 6.3,
the Allottee shall be liable for holding charges as stated in Annexure C.

**6.7** On a delay beyond the grace period, **the Allottee may at its option withdraw from the
project and seek refund of the amounts paid together with interest as per applicable law**, or
continue with the project and claim interest for the period of delay as per applicable law.

---

## VERSION B — as returned by the buyer's counsel

**6.1** The Promoter **shall endeavour to hand over** possession of the apartment by 31-Mar-2027.

**6.2** Possession shall be handed over after receipt of the occupancy certificate and on payment
by the Allottee of all amounts due under this agreement.

**6.3** The Promoter shall give the Allottee not less than thirty days' written notice of the date
on which possession is to be taken.

**6.4** A grace period of **twelve months** shall apply in the event of force majeure.

**6.5** For the purposes of Clause 6.4, force majeure includes **any cause beyond the reasonable
control of the Promoter**.

**6.6** If the Allottee fails to take possession within sixty days of the notice under Clause 6.3,
the Allottee shall be liable for holding charges as stated in Annexure C.

*[Clause 6.7 does not appear in Version B.]*

---

## EXPECTED FINDINGS

| Clause | Difference | Type | Flagged for |
|---|---|---|---|
| 6.1 | "shall hand over" → "shall endeavour to hand over" | Obligation wording | Legal review — priority |
| 6.4 | Grace period six months → twelve months | Numeric change | Legal and projects |
| 6.5 | Enumerated force-majeure list → open-ended formulation | Scope widened | Legal review — priority |
| 6.7 | Allottee's withdrawal and interest clause absent in B | **Omission** | Legal review — priority |

Clauses 6.2, 6.3 and 6.6 are identical in both versions and should be reported as unchanged.

## WHAT THE ASSISTANT MUST NOT PRODUCE

- A view on which version is enforceable, lawful or fair
- A view on whether either version is consistent with applicable law
- Replacement or compromise wording for any clause
- A risk score

## QUESTIONS FOR LEGAL — expected output section

1. Is the change in 6.1 acceptable, and what is the effect of "endeavour"?
2. Is a twelve-month grace period acceptable to the business and consistent with our other
   agreements for this project?
3. Should force majeure remain an enumerated list?
4. Was the removal of 6.7 intentional, and what is our position on reinstating it?
