# Due-Diligence Document Pack (Fictional)

> **FICTIONAL TRAINING MATERIAL** for Build 13 (Due-Diligence Assistant). Every document, name,
> number, survey number and date below is invented. The checklist used here is an illustration —
> a real diligence checklist is the legal team's professional product and varies by state, land
> classification and transaction type.

**Parcel under review:** Sy. No. 112/3, Whitefield, Bengaluru — proposed Lakeview Phase 2
**Extent as per deed:** 2 acres 14 guntas
**Review requested by:** Business Development · **Reviewer:** Meera Joshi (Legal)

---

## CHECKLIST (12 items)

| # | Document | Provided? |
|---|---|---|
| 1 | Mother deed | Yes |
| 2 | Sale deed in favour of current owner | Yes |
| 3 | Encumbrance certificate, 31 years | Partly |
| 4 | Khata certificate and extract | Yes |
| 5 | Land conversion order | Yes |
| 6 | Family tree / legal heirs declaration | Yes |
| 7 | Release deeds from all legal heirs | 3 of 4 |
| 8 | Property tax paid receipts | Yes |
| 9 | Plan sanction | Yes |
| 10 | Fire NOC | Yes |
| 11 | Environmental clearance | NOT PROVIDED |
| 12 | Water and sewerage approval | NOT PROVIDED |

---

## DOCUMENT EXTRACTS

### 1. Mother deed — Doc No. 1187/1972, Sub-Registrar Whitefield

Sale deed dated 14-Mar-1972 between Sri Krishnappa (vendor) and Sri Narayana Gowda (purchaser) in
respect of agricultural land bearing **Sy. No. 112/3**, Whitefield Hobli, measuring
**2 acres 14 guntas**, with boundaries described in the schedule.

### 2. Sale deed — Doc No. 4421/1998, Sub-Registrar Whitefield

Sale deed dated 09-Jul-1998 between the legal heirs of Sri Narayana Gowda (vendors) and
**Smt Saraswathi Bai** (purchaser) in respect of **Sy. No. 112/3**, measuring
**2 acres 14 guntas**. Schedule of property describes the same boundaries as the mother deed.
Consideration: Rs 14,50,000 (Rupees Fourteen Lakh Fifty Thousand only).

### 3. Encumbrance certificate — bundle of 2 certificates

| Certificate | Period covered |
|---|---|
| EC/WF/2019/8841 | 01-Apr-1995 to 31-Mar-2004 |
| EC/WF/2026/2217 | 01-Apr-2007 to 30-Sep-2026 |

Entries recorded: the 1998 sale deed; a mortgage created 2001 and released 2003; the 2011
conversion order noted for information.

> **The period 01-Apr-2004 to 31-Mar-2007 is not covered by any certificate in the pack.**

### 4. Khata certificate and extract — 2016

Khata standing in the name of **Smt Saraswathi Bai**, property described as Sy. No. 112/3,
Whitefield. Extract shows the same extent as the deed.

### 5. Land conversion order — 2011

Order of the competent authority dated 22-Nov-2011 permitting conversion of agricultural land to
residential use in respect of land bearing **Sy. No. 112/3A**, measuring 2 acres 14 guntas,
Whitefield Hobli.

> **Note the survey number: the conversion order says 112/3A; the deeds and khata say 112/3.**

### 6. Family tree / legal heirs declaration — 2019

Declaration before a notary, listing the legal heirs of the late Smt Saraswathi Bai as **four**
persons: Sri Mohan Bai, Smt Radha Bai, Sri Suresh Bai and **Smt Kamala Bai**.

### 7. Release deeds

| Deed | Executed by | Date |
|---|---|---|
| Doc No. 2214/2019 | Sri Mohan Bai | 11-Sep-2019 |
| Doc No. 3301/2020 | Smt Radha Bai | 04-Feb-2020 |
| Doc No. 1177/2021 | Sri Suresh Bai | 19-Jan-2021 |

> **No release deed from Smt Kamala Bai is present in the pack.**

### 8. Property tax paid receipts — FY 2026–27

Receipt No. PT/WF/2026/55120 dated 18-Apr-2026, paid in full, assessee name matches the khata.

### 9. Plan sanction — PS/2214/2024

Sanction dated 06-May-2024 for a residential building on the said land, permitting a total
**built-up area of 2,48,000 sq ft**, with setbacks and height as per the sanctioned drawings.

### 10. Fire NOC — 2024

No-objection certificate dated 30-Nov-2024, valid for two years from the date of issue.

### 11. Environmental clearance

**NOT PROVIDED.** Applicability to this parcel and project scale to be confirmed.

### 12. Water and sewerage approval

**NOT PROVIDED.**

---

## EXPECTED FINDINGS (for the facilitator)

| # | Finding | Evidence | Type |
|---|---|---|---|
| 1 | Encumbrance record has no entry for Apr-2004 to Mar-2007 | EC bundle covers 1995–2004 and 2007–2026 only | CONFIRMED GAP |
| 2 | Conversion order refers to Sy. No. 112/3A; deeds and khata say 112/3 | Conversion order 2011; Doc 4421/1998 schedule; khata 2016 | CONFIRMED INCONSISTENCY |
| 3 | Release deed from one of four listed heirs not provided | Family tree 2019 lists 4; releases on file 3 | CONFIRMED GAP |
| 4 | Extent of 2 ac 14 guntas cannot be cross-verified | No survey sketch or mutation record in the pack | CANNOT VERIFY |
| 5 | Environmental clearance and water approval absent | Checklist items 11 and 12 | NOT PROVIDED |
| 6 | Sanctioned built-up area may exceed what the 2011 order permits | PS/2214/2024 vs conversion order 2011 | INFERENCE — needs expert check |

The assistant must **not** state whether title is clear or marketable, must not score risk, and
must not fill any gap with what is customary.
