# Marketing Copy Drafts — Unverified (Fictional)

> **FICTIONAL TRAINING MATERIAL** for Demo 22 (Marketing Claim Verifier). These drafts contain
> deliberate errors. **None of them may be published, reused or adapted.** Check each against
> `04-project-registration-sheets.md`.

---

## DRAFT 1 — launch banner (the one used on the slide)

> Welcome to Verdant Heights — 500 luxury homes with a 20,000 sq ft clubhouse and rooftop infinity
> pool. Possession December 2026. Fully approved by all authorities. Assured 8% rental returns.
> Metro station just 5 minutes away.

**Planted failures:** 8 claims, 7 of them factual and unsupported.

| Claim | Sheet says | Verdict |
|---|---|---|
| 500 homes | 480 units | UNSUPPORTED |
| 20,000 sq ft clubhouse | 12,000 sq ft | UNSUPPORTED |
| Rooftop infinity pool | Pool at podium level | UNSUPPORTED |
| Possession December 2026 | Published Mar-2027 | UNSUPPORTED |
| Fully approved by all authorities | OC not yet obtained | UNSUPPORTED |
| Assured 8% rental returns | No rental assurance exists | UNSUPPORTED — ESCALATE to legal |
| Metro 5 minutes away | 3.2 km to nearest metro | UNSUPPORTED |
| "Luxury" | Not a factual claim | SUBJECTIVE — allowed |

**Corrected version:**

> Welcome to Verdant Heights — 480 homes in 2 and 3 BHK configurations, with a 12,000 sq ft
> clubhouse and a podium-level swimming pool. Possession is published as March 2027. Plan sanction
> and fire NOC are on file; the occupancy certificate is yet to be obtained. The nearest metro
> station is 3.2 km away. RERA Reg. No. PRM/KA/RERA/1251/446/PR/251103/009988. Artistic
> impressions; specifications are subject to the agreement for sale.

---

## DRAFT 2 — social post

> Only 12 units left at Verdant Heights! 3 BHK from Rs 1.35 Cr all inclusive. Walk to the upcoming
> tech park. Zero maintenance for 2 years. Book this week and save 5%.

**Planted failures:** unit availability (243 available, not 12); price below the published range
and described as "all inclusive" with no break-up; "upcoming tech park" is unsupported and
speculative; maintenance waiver not in approved material; a discount the sheet does not authorise.

---

## DRAFT 3 — email to enquiry list

> Dear buyer, construction at Verdant Heights is ahead of schedule and handover will begin early.
> The clubhouse is ready and the pool is operational. Our EC and OC are in place. Prices increase
> from 1 November.

**Planted failures:** "ahead of schedule" and "handover will begin early" contradict the published
possession; clubhouse and pool readiness are not stated anywhere; the OC has not been obtained;
"EC in place" is false for this project's pack; a price-increase deadline is a pressure claim with
no approved basis.

---

## DRAFT 4 — a clean draft, for contrast

> Verdant Heights, Whitefield — 480 homes across four towers, in 2 BHK (1,180 sq ft saleable,
> 762 sq ft carpet) and 3 BHK (1,620 sq ft saleable, 1,042 sq ft carpet) configurations. Amenities
> include a 12,000 sq ft clubhouse, a podium-level pool, two landscaped parks and EV-ready parking
> provision. Published possession: March 2027. Published price range: 2 BHK Rs 1.05–1.18 Cr,
> 3 BHK Rs 1.42–1.68 Cr; statutory and other charges quoted separately. RERA Reg. No.
> PRM/KA/RERA/1251/446/PR/251103/009988. Artistic impressions; specifications are subject to the
> agreement for sale.

Every factual claim here traces to the registration sheet and the approved brochure. Use it to show
the room that accuracy costs a little flourish, not the campaign.

---

## FACILITATOR NOTE

Run Draft 1 in the session. Keep Drafts 2 and 3 for participants to verify themselves, and Draft 4
as the answer key for what "supported" looks like. Claims of the assured-return, guaranteed-rental
or buy-back kind are not corrected — they are escalated to legal, because the issue is the
representation itself, not the number in it.
